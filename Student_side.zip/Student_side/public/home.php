<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administration</title>
    <link rel="icon" href="public/images/fav.png">
    <link rel="stylesheet" href="../style.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Geologica:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
</head>

<body class="bg-gray-200">
    <div class="overflow-hidden">
        <nav class="bg-white py-2 flex justify-center shadow-lg">
            <ul>
                <li><img src="public/images/logo.png" alt="bmu" class="w-32"></li>
            </ul>
        </nav>
        <div class="relative">
            <div class="bg-[#000]">
                <img src="public/images/img3.jpeg" alt="bmu" class="w-full h-[30rem] opacity-40 bg-cover">
            </div>
            <div class="flex justify-center">
                <h1 class="absolute text-white top-[10rem] text-[5rem] font-serif animate__animated animate__zoomIn" style="font-family: 'Geologica', sans-serif;">Bhagwan Mahavir University</h1>
            </div>
        </div>
        <div class="absolute w-full px-28 top-[29rem]">
            <div class="flex justify-between" style="font-family: 'Geologica', sans-serif;">
                <a href="bonafide">
                    <div class="bg-white flex items-center w-[22rem] h-48 rounded-xl shadow-lg">
                        <p class="text-4xl font-medium text-center px-6">Bonafide Certificate</p>
                    </div>
                </a>
                <div class="bg-white w-[22rem] h-48 rounded-xl shadow-lg">

                </div>
                <div class="bg-white w-[22rem] h-48 rounded-xl shadow-lg">

                </div>
            </div>
        </div>
    </div>
</body>

</html>